<!DOCTYPE HTML>
<html>
<body>

  <p>Header...</p>

  <script>
    alert('Hello, World!')
  </script>

  <p>...Footer</p>

</body>
</html>
