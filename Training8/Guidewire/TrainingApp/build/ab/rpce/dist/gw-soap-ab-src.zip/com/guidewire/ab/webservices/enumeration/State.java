/**
 * State.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2.1 Feb 24, 2009 (02:51:19 PST) WSDL2Java emitter.
 */

package com.guidewire.ab.webservices.enumeration;

public class State implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected State(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    private static java.lang.String _TC_Hokkaido;
    private static java.lang.String _TC_Aomori;
    private static java.lang.String _TC_Iwate;
    private static java.lang.String _TC_Miyagi;
    private static java.lang.String _TC_Akita;
    private static java.lang.String _TC_Yamagata;
    private static java.lang.String _TC_Fukushima;
    private static java.lang.String _TC_Ibaraki;
    private static java.lang.String _TC_AU_JBT;
    private static java.lang.String _TC_Tochigi;
    private static java.lang.String _TC_Gumma;
    private static java.lang.String _TC_Saitama;
    private static java.lang.String _TC_Chiba;
    private static java.lang.String _TC_Tokyo;
    private static java.lang.String _TC_Kanagawa;
    private static java.lang.String _TC_Niigata;
    private static java.lang.String _TC_Toyama;
    private static java.lang.String _TC_Ishikawa;
    private static java.lang.String _TC_Fukui;
    private static java.lang.String _TC_Yamanashi;
    private static java.lang.String _TC_Nagano;
    private static java.lang.String _TC_Gifu;
    private static java.lang.String _TC_Shizuoka;
    private static java.lang.String _TC_Aichi;
    private static java.lang.String _TC_Mie;
    private static java.lang.String _TC_Shiga;
    private static java.lang.String _TC_Kyoto;
    private static java.lang.String _TC_Osaka;
    private static java.lang.String _TC_Hyogo;
    private static java.lang.String _TC_Nara;
    private static java.lang.String _TC_Wakayama;
    private static java.lang.String _TC_Tottori;
    private static java.lang.String _TC_Shimane;
    private static java.lang.String _TC_Okayama;
    private static java.lang.String _TC_Hiroshima;
    private static java.lang.String _TC_Yamaguchi;
    private static java.lang.String _TC_Tokushima;
    private static java.lang.String _TC_Kagawa;
    private static java.lang.String _TC_Ehime;
    private static java.lang.String _TC_Kochi;
    private static java.lang.String _TC_Fukuoka;
    private static java.lang.String _TC_Saga;
    private static java.lang.String _TC_Nagasaki;
    private static java.lang.String _TC_Kumamoto;
    private static java.lang.String _TC_Oita;
    private static java.lang.String _TC_Miyazaki;
    private static java.lang.String _TC_Kagoshima;
    private static java.lang.String _TC_Okinawa;
    private static java.lang.String _TC_AU_ACT;
    private static java.lang.String _TC_AL;
    private static java.lang.String _TC_AK;
    private static java.lang.String _TC_AB;
    private static java.lang.String _TC_AZ;
    private static java.lang.String _TC_AR;
    private static java.lang.String _TC_DE_BW;
    private static java.lang.String _TC_DE_BY;
    private static java.lang.String _TC_DE_BE;
    private static java.lang.String _TC_DE_BB;
    private static java.lang.String _TC_DE_HB;
    private static java.lang.String _TC_BC;
    private static java.lang.String _TC_CA;
    private static java.lang.String _TC_CO;
    private static java.lang.String _TC_CT;
    private static java.lang.String _TC_DE;
    private static java.lang.String _TC_DC;
    private static java.lang.String _TC_FL;
    private static java.lang.String _TC_GA;
    private static java.lang.String _TC_DE_HH;
    private static java.lang.String _TC_HI;
    private static java.lang.String _TC_DE_HE;
    private static java.lang.String _TC_ID;
    private static java.lang.String _TC_IL;
    private static java.lang.String _TC_IN;
    private static java.lang.String _TC_IA;
    private static java.lang.String _TC_KS;
    private static java.lang.String _TC_KY;
    private static java.lang.String _TC_LA;
    private static java.lang.String _TC_DE_NI;
    private static java.lang.String _TC_ME;
    private static java.lang.String _TC_MB;
    private static java.lang.String _TC_MD;
    private static java.lang.String _TC_MA;
    private static java.lang.String _TC_DE_MV;
    private static java.lang.String _TC_MI;
    private static java.lang.String _TC_MN;
    private static java.lang.String _TC_MS;
    private static java.lang.String _TC_MO;
    private static java.lang.String _TC_MT;
    private static java.lang.String _TC_NE;
    private static java.lang.String _TC_NV;
    private static java.lang.String _TC_NB;
    private static java.lang.String _TC_NH;
    private static java.lang.String _TC_NJ;
    private static java.lang.String _TC_NM;
    private static java.lang.String _TC_AU_NSW;
    private static java.lang.String _TC_NY;
    private static java.lang.String _TC_NL;
    private static java.lang.String _TC_NC;
    private static java.lang.String _TC_ND;
    private static java.lang.String _TC_DE_NW;
    private static java.lang.String _TC_AU_NT;
    private static java.lang.String _TC_NT;
    private static java.lang.String _TC_NS;
    private static java.lang.String _TC_NU;
    private static java.lang.String _TC_OH;
    private static java.lang.String _TC_OK;
    private static java.lang.String _TC_ON;
    private static java.lang.String _TC_OR;
    private static java.lang.String _TC_PA;
    private static java.lang.String _TC_PE;
    private static java.lang.String _TC_PR;
    private static java.lang.String _TC_QC;
    private static java.lang.String _TC_AU_QLD;
    private static java.lang.String _TC_DE_RP;
    private static java.lang.String _TC_RI;
    private static java.lang.String _TC_DE_SL;
    private static java.lang.String _TC_SK;
    private static java.lang.String _TC_DE_SN;
    private static java.lang.String _TC_DE_ST;
    private static java.lang.String _TC_DE_SH;
    private static java.lang.String _TC_AU_SA;
    private static java.lang.String _TC_SC;
    private static java.lang.String _TC_SD;
    private static java.lang.String _TC_AU_TAS;
    private static java.lang.String _TC_TN;
    private static java.lang.String _TC_TX;
    private static java.lang.String _TC_DE_TH;
    private static java.lang.String _TC_UT;
    private static java.lang.String _TC_VT;
    private static java.lang.String _TC_AU_VIC;
    private static java.lang.String _TC_VA;
    private static java.lang.String _TC_WA;
    private static java.lang.String _TC_WV;
    private static java.lang.String _TC_AU_WA;
    private static java.lang.String _TC_WI;
    private static java.lang.String _TC_WY;
    private static java.lang.String _TC_YT;

/**
 * Hokkaido
 */
    public static State TC_Hokkaido;

/**
 * Aomori
 */
    public static State TC_Aomori;

/**
 * Iwate
 */
    public static State TC_Iwate;

/**
 * Miyagi
 */
    public static State TC_Miyagi;

/**
 * Akita
 */
    public static State TC_Akita;

/**
 * Yamagata
 */
    public static State TC_Yamagata;

/**
 * Fukushima
 */
    public static State TC_Fukushima;

/**
 * Ibaraki
 */
    public static State TC_Ibaraki;

/**
 * Jervis Bay Territory
 */
    public static State TC_AU_JBT;

/**
 * Tochigi
 */
    public static State TC_Tochigi;

/**
 * Gumma
 */
    public static State TC_Gumma;

/**
 * Saitama
 */
    public static State TC_Saitama;

/**
 * Chiba
 */
    public static State TC_Chiba;

/**
 * Tokyo
 */
    public static State TC_Tokyo;

/**
 * Kanagawa
 */
    public static State TC_Kanagawa;

/**
 * Niigata
 */
    public static State TC_Niigata;

/**
 * Toyama
 */
    public static State TC_Toyama;

/**
 * Ishikawa
 */
    public static State TC_Ishikawa;

/**
 * Fukui
 */
    public static State TC_Fukui;

/**
 * Yamanashi
 */
    public static State TC_Yamanashi;

/**
 * Nagano
 */
    public static State TC_Nagano;

/**
 * Gifu
 */
    public static State TC_Gifu;

/**
 * Shizuoka
 */
    public static State TC_Shizuoka;

/**
 * Aichi
 */
    public static State TC_Aichi;

/**
 * Mie
 */
    public static State TC_Mie;

/**
 * Shiga
 */
    public static State TC_Shiga;

/**
 * Kyoto
 */
    public static State TC_Kyoto;

/**
 * Osaka
 */
    public static State TC_Osaka;

/**
 * Hyogo
 */
    public static State TC_Hyogo;

/**
 * Nara
 */
    public static State TC_Nara;

/**
 * Wakayama
 */
    public static State TC_Wakayama;

/**
 * Tottori
 */
    public static State TC_Tottori;

/**
 * Shimane
 */
    public static State TC_Shimane;

/**
 * Okayama
 */
    public static State TC_Okayama;

/**
 * Hiroshima
 */
    public static State TC_Hiroshima;

/**
 * Yamaguchi
 */
    public static State TC_Yamaguchi;

/**
 * Tokushima
 */
    public static State TC_Tokushima;

/**
 * Kagawa
 */
    public static State TC_Kagawa;

/**
 * Ehime
 */
    public static State TC_Ehime;

/**
 * Kochi
 */
    public static State TC_Kochi;

/**
 * Fukuoka
 */
    public static State TC_Fukuoka;

/**
 * Saga
 */
    public static State TC_Saga;

/**
 * Nagasaki
 */
    public static State TC_Nagasaki;

/**
 * Kumamoto
 */
    public static State TC_Kumamoto;

/**
 * Oita
 */
    public static State TC_Oita;

/**
 * Miyazaki
 */
    public static State TC_Miyazaki;

/**
 * Kagoshima
 */
    public static State TC_Kagoshima;

/**
 * Okinawa
 */
    public static State TC_Okinawa;

/**
 * Australian Capital Territory
 */
    public static State TC_AU_ACT;

/**
 * Alabama
 */
    public static State TC_AL;

/**
 * Alaska
 */
    public static State TC_AK;

/**
 * Alberta
 */
    public static State TC_AB;

/**
 * Arizona
 */
    public static State TC_AZ;

/**
 * Arkansas
 */
    public static State TC_AR;

/**
 * Baden-Wuerttemberg
 */
    public static State TC_DE_BW;

/**
 * Bavaria
 */
    public static State TC_DE_BY;

/**
 * Berlin
 */
    public static State TC_DE_BE;

/**
 * Brandenburg
 */
    public static State TC_DE_BB;

/**
 * Bremen
 */
    public static State TC_DE_HB;

/**
 * British Columbia
 */
    public static State TC_BC;

/**
 * California
 */
    public static State TC_CA;

/**
 * Colorado
 */
    public static State TC_CO;

/**
 * Connecticut
 */
    public static State TC_CT;

/**
 * Delaware
 */
    public static State TC_DE;

/**
 * District of Columbia
 */
    public static State TC_DC;

/**
 * Florida
 */
    public static State TC_FL;

/**
 * Georgia
 */
    public static State TC_GA;

/**
 * Hamburg
 */
    public static State TC_DE_HH;

/**
 * Hawaii
 */
    public static State TC_HI;

/**
 * Hesse
 */
    public static State TC_DE_HE;

/**
 * Idaho
 */
    public static State TC_ID;

/**
 * Illinois
 */
    public static State TC_IL;

/**
 * Indiana
 */
    public static State TC_IN;

/**
 * Iowa
 */
    public static State TC_IA;

/**
 * Kansas
 */
    public static State TC_KS;

/**
 * Kentucky
 */
    public static State TC_KY;

/**
 * Louisiana
 */
    public static State TC_LA;

/**
 * Lower Saxony
 */
    public static State TC_DE_NI;

/**
 * Maine
 */
    public static State TC_ME;

/**
 * Manitoba
 */
    public static State TC_MB;

/**
 * Maryland
 */
    public static State TC_MD;

/**
 * Massachusetts
 */
    public static State TC_MA;

/**
 * Mecklenburg-Vorpommern
 */
    public static State TC_DE_MV;

/**
 * Michigan
 */
    public static State TC_MI;

/**
 * Minnesota
 */
    public static State TC_MN;

/**
 * Mississippi
 */
    public static State TC_MS;

/**
 * Missouri
 */
    public static State TC_MO;

/**
 * Montana
 */
    public static State TC_MT;

/**
 * Nebraska
 */
    public static State TC_NE;

/**
 * Nevada
 */
    public static State TC_NV;

/**
 * New Brunswick
 */
    public static State TC_NB;

/**
 * New Hampshire
 */
    public static State TC_NH;

/**
 * New Jersey
 */
    public static State TC_NJ;

/**
 * New Mexico
 */
    public static State TC_NM;

/**
 * New South Wales
 */
    public static State TC_AU_NSW;

/**
 * New York
 */
    public static State TC_NY;

/**
 * Newfoundland and Labrador
 */
    public static State TC_NL;

/**
 * North Carolina
 */
    public static State TC_NC;

/**
 * North Dakota
 */
    public static State TC_ND;

/**
 * North Rhine-Westphalia
 */
    public static State TC_DE_NW;

/**
 * Northern Territory
 */
    public static State TC_AU_NT;

/**
 * Northwest Territories
 */
    public static State TC_NT;

/**
 * Nova Scotia
 */
    public static State TC_NS;

/**
 * Nunavut
 */
    public static State TC_NU;

/**
 * Ohio
 */
    public static State TC_OH;

/**
 * Oklahoma
 */
    public static State TC_OK;

/**
 * Ontario
 */
    public static State TC_ON;

/**
 * Oregon
 */
    public static State TC_OR;

/**
 * Pennsylvania
 */
    public static State TC_PA;

/**
 * Prince Edward Island
 */
    public static State TC_PE;

/**
 * Puerto Rico
 */
    public static State TC_PR;

/**
 * Quebec
 */
    public static State TC_QC;

/**
 * Queensland
 */
    public static State TC_AU_QLD;

/**
 * Rhineland-Palatinate
 */
    public static State TC_DE_RP;

/**
 * Rhode Island
 */
    public static State TC_RI;

/**
 * Saarland
 */
    public static State TC_DE_SL;

/**
 * Saskatchewan
 */
    public static State TC_SK;

/**
 * Saxony
 */
    public static State TC_DE_SN;

/**
 * Saxony-Anhalt
 */
    public static State TC_DE_ST;

/**
 * Schleswig-Holstein
 */
    public static State TC_DE_SH;

/**
 * South Australia
 */
    public static State TC_AU_SA;

/**
 * South Carolina
 */
    public static State TC_SC;

/**
 * South Dakota
 */
    public static State TC_SD;

/**
 * Tasmania
 */
    public static State TC_AU_TAS;

/**
 * Tennessee
 */
    public static State TC_TN;

/**
 * Texas
 */
    public static State TC_TX;

/**
 * Thuringia
 */
    public static State TC_DE_TH;

/**
 * Utah
 */
    public static State TC_UT;

/**
 * Vermont
 */
    public static State TC_VT;

/**
 * Victoria
 */
    public static State TC_AU_VIC;

/**
 * Virginia
 */
    public static State TC_VA;

/**
 * Washington
 */
    public static State TC_WA;

/**
 * West Virginia
 */
    public static State TC_WV;

/**
 * Western Australia
 */
    public static State TC_AU_WA;

/**
 * Wisconsin
 */
    public static State TC_WI;

/**
 * Wyoming
 */
    public static State TC_WY;

/**
 * Yukon
 */
    public static State TC_YT;

    private static void initValues0() {
      _TC_Hokkaido = "TC_Hokkaido";
      TC_Hokkaido = new State(_TC_Hokkaido);
      _TC_Aomori = "TC_Aomori";
      TC_Aomori = new State(_TC_Aomori);
      _TC_Iwate = "TC_Iwate";
      TC_Iwate = new State(_TC_Iwate);
      _TC_Miyagi = "TC_Miyagi";
      TC_Miyagi = new State(_TC_Miyagi);
      _TC_Akita = "TC_Akita";
      TC_Akita = new State(_TC_Akita);
      _TC_Yamagata = "TC_Yamagata";
      TC_Yamagata = new State(_TC_Yamagata);
      _TC_Fukushima = "TC_Fukushima";
      TC_Fukushima = new State(_TC_Fukushima);
      _TC_Ibaraki = "TC_Ibaraki";
      TC_Ibaraki = new State(_TC_Ibaraki);
      _TC_AU_JBT = "TC_AU_JBT";
      TC_AU_JBT = new State(_TC_AU_JBT);
      _TC_Tochigi = "TC_Tochigi";
      TC_Tochigi = new State(_TC_Tochigi);
      _TC_Gumma = "TC_Gumma";
      TC_Gumma = new State(_TC_Gumma);
      _TC_Saitama = "TC_Saitama";
      TC_Saitama = new State(_TC_Saitama);
      _TC_Chiba = "TC_Chiba";
      TC_Chiba = new State(_TC_Chiba);
      _TC_Tokyo = "TC_Tokyo";
      TC_Tokyo = new State(_TC_Tokyo);
      _TC_Kanagawa = "TC_Kanagawa";
      TC_Kanagawa = new State(_TC_Kanagawa);
      _TC_Niigata = "TC_Niigata";
      TC_Niigata = new State(_TC_Niigata);
      _TC_Toyama = "TC_Toyama";
      TC_Toyama = new State(_TC_Toyama);
      _TC_Ishikawa = "TC_Ishikawa";
      TC_Ishikawa = new State(_TC_Ishikawa);
      _TC_Fukui = "TC_Fukui";
      TC_Fukui = new State(_TC_Fukui);
      _TC_Yamanashi = "TC_Yamanashi";
      TC_Yamanashi = new State(_TC_Yamanashi);
      _TC_Nagano = "TC_Nagano";
      TC_Nagano = new State(_TC_Nagano);
      _TC_Gifu = "TC_Gifu";
      TC_Gifu = new State(_TC_Gifu);
      _TC_Shizuoka = "TC_Shizuoka";
      TC_Shizuoka = new State(_TC_Shizuoka);
      _TC_Aichi = "TC_Aichi";
      TC_Aichi = new State(_TC_Aichi);
      _TC_Mie = "TC_Mie";
      TC_Mie = new State(_TC_Mie);
      _TC_Shiga = "TC_Shiga";
      TC_Shiga = new State(_TC_Shiga);
      _TC_Kyoto = "TC_Kyoto";
      TC_Kyoto = new State(_TC_Kyoto);
      _TC_Osaka = "TC_Osaka";
      TC_Osaka = new State(_TC_Osaka);
      _TC_Hyogo = "TC_Hyogo";
      TC_Hyogo = new State(_TC_Hyogo);
      _TC_Nara = "TC_Nara";
      TC_Nara = new State(_TC_Nara);
      _TC_Wakayama = "TC_Wakayama";
      TC_Wakayama = new State(_TC_Wakayama);
      _TC_Tottori = "TC_Tottori";
      TC_Tottori = new State(_TC_Tottori);
      _TC_Shimane = "TC_Shimane";
      TC_Shimane = new State(_TC_Shimane);
      _TC_Okayama = "TC_Okayama";
      TC_Okayama = new State(_TC_Okayama);
      _TC_Hiroshima = "TC_Hiroshima";
      TC_Hiroshima = new State(_TC_Hiroshima);
      _TC_Yamaguchi = "TC_Yamaguchi";
      TC_Yamaguchi = new State(_TC_Yamaguchi);
      _TC_Tokushima = "TC_Tokushima";
      TC_Tokushima = new State(_TC_Tokushima);
      _TC_Kagawa = "TC_Kagawa";
      TC_Kagawa = new State(_TC_Kagawa);
      _TC_Ehime = "TC_Ehime";
      TC_Ehime = new State(_TC_Ehime);
      _TC_Kochi = "TC_Kochi";
      TC_Kochi = new State(_TC_Kochi);
      _TC_Fukuoka = "TC_Fukuoka";
      TC_Fukuoka = new State(_TC_Fukuoka);
      _TC_Saga = "TC_Saga";
      TC_Saga = new State(_TC_Saga);
      _TC_Nagasaki = "TC_Nagasaki";
      TC_Nagasaki = new State(_TC_Nagasaki);
      _TC_Kumamoto = "TC_Kumamoto";
      TC_Kumamoto = new State(_TC_Kumamoto);
      _TC_Oita = "TC_Oita";
      TC_Oita = new State(_TC_Oita);
      _TC_Miyazaki = "TC_Miyazaki";
      TC_Miyazaki = new State(_TC_Miyazaki);
      _TC_Kagoshima = "TC_Kagoshima";
      TC_Kagoshima = new State(_TC_Kagoshima);
      _TC_Okinawa = "TC_Okinawa";
      TC_Okinawa = new State(_TC_Okinawa);
      _TC_AU_ACT = "TC_AU_ACT";
      TC_AU_ACT = new State(_TC_AU_ACT);
      _TC_AL = "TC_AL";
      TC_AL = new State(_TC_AL);
      _TC_AK = "TC_AK";
      TC_AK = new State(_TC_AK);
      _TC_AB = "TC_AB";
      TC_AB = new State(_TC_AB);
      _TC_AZ = "TC_AZ";
      TC_AZ = new State(_TC_AZ);
      _TC_AR = "TC_AR";
      TC_AR = new State(_TC_AR);
      _TC_DE_BW = "TC_DE_BW";
      TC_DE_BW = new State(_TC_DE_BW);
      _TC_DE_BY = "TC_DE_BY";
      TC_DE_BY = new State(_TC_DE_BY);
      _TC_DE_BE = "TC_DE_BE";
      TC_DE_BE = new State(_TC_DE_BE);
      _TC_DE_BB = "TC_DE_BB";
      TC_DE_BB = new State(_TC_DE_BB);
      _TC_DE_HB = "TC_DE_HB";
      TC_DE_HB = new State(_TC_DE_HB);
      _TC_BC = "TC_BC";
      TC_BC = new State(_TC_BC);
      _TC_CA = "TC_CA";
      TC_CA = new State(_TC_CA);
      _TC_CO = "TC_CO";
      TC_CO = new State(_TC_CO);
      _TC_CT = "TC_CT";
      TC_CT = new State(_TC_CT);
      _TC_DE = "TC_DE";
      TC_DE = new State(_TC_DE);
      _TC_DC = "TC_DC";
      TC_DC = new State(_TC_DC);
      _TC_FL = "TC_FL";
      TC_FL = new State(_TC_FL);
      _TC_GA = "TC_GA";
      TC_GA = new State(_TC_GA);
      _TC_DE_HH = "TC_DE_HH";
      TC_DE_HH = new State(_TC_DE_HH);
      _TC_HI = "TC_HI";
      TC_HI = new State(_TC_HI);
      _TC_DE_HE = "TC_DE_HE";
      TC_DE_HE = new State(_TC_DE_HE);
      _TC_ID = "TC_ID";
      TC_ID = new State(_TC_ID);
      _TC_IL = "TC_IL";
      TC_IL = new State(_TC_IL);
      _TC_IN = "TC_IN";
      TC_IN = new State(_TC_IN);
      _TC_IA = "TC_IA";
      TC_IA = new State(_TC_IA);
      _TC_KS = "TC_KS";
      TC_KS = new State(_TC_KS);
      _TC_KY = "TC_KY";
      TC_KY = new State(_TC_KY);
      _TC_LA = "TC_LA";
      TC_LA = new State(_TC_LA);
      _TC_DE_NI = "TC_DE_NI";
      TC_DE_NI = new State(_TC_DE_NI);
      _TC_ME = "TC_ME";
      TC_ME = new State(_TC_ME);
      _TC_MB = "TC_MB";
      TC_MB = new State(_TC_MB);
      _TC_MD = "TC_MD";
      TC_MD = new State(_TC_MD);
      _TC_MA = "TC_MA";
      TC_MA = new State(_TC_MA);
      _TC_DE_MV = "TC_DE_MV";
      TC_DE_MV = new State(_TC_DE_MV);
      _TC_MI = "TC_MI";
      TC_MI = new State(_TC_MI);
      _TC_MN = "TC_MN";
      TC_MN = new State(_TC_MN);
      _TC_MS = "TC_MS";
      TC_MS = new State(_TC_MS);
      _TC_MO = "TC_MO";
      TC_MO = new State(_TC_MO);
      _TC_MT = "TC_MT";
      TC_MT = new State(_TC_MT);
      _TC_NE = "TC_NE";
      TC_NE = new State(_TC_NE);
      _TC_NV = "TC_NV";
      TC_NV = new State(_TC_NV);
      _TC_NB = "TC_NB";
      TC_NB = new State(_TC_NB);
      _TC_NH = "TC_NH";
      TC_NH = new State(_TC_NH);
      _TC_NJ = "TC_NJ";
      TC_NJ = new State(_TC_NJ);
      _TC_NM = "TC_NM";
      TC_NM = new State(_TC_NM);
      _TC_AU_NSW = "TC_AU_NSW";
      TC_AU_NSW = new State(_TC_AU_NSW);
      _TC_NY = "TC_NY";
      TC_NY = new State(_TC_NY);
      _TC_NL = "TC_NL";
      TC_NL = new State(_TC_NL);
      _TC_NC = "TC_NC";
      TC_NC = new State(_TC_NC);
      _TC_ND = "TC_ND";
      TC_ND = new State(_TC_ND);
      _TC_DE_NW = "TC_DE_NW";
      TC_DE_NW = new State(_TC_DE_NW);
      _TC_AU_NT = "TC_AU_NT";
      TC_AU_NT = new State(_TC_AU_NT);
      _TC_NT = "TC_NT";
      TC_NT = new State(_TC_NT);
      _TC_NS = "TC_NS";
      TC_NS = new State(_TC_NS);
      _TC_NU = "TC_NU";
      TC_NU = new State(_TC_NU);
      _TC_OH = "TC_OH";
      TC_OH = new State(_TC_OH);
      _TC_OK = "TC_OK";
      TC_OK = new State(_TC_OK);
      _TC_ON = "TC_ON";
      TC_ON = new State(_TC_ON);
      _TC_OR = "TC_OR";
      TC_OR = new State(_TC_OR);
      _TC_PA = "TC_PA";
      TC_PA = new State(_TC_PA);
      _TC_PE = "TC_PE";
      TC_PE = new State(_TC_PE);
      _TC_PR = "TC_PR";
      TC_PR = new State(_TC_PR);
      _TC_QC = "TC_QC";
      TC_QC = new State(_TC_QC);
      _TC_AU_QLD = "TC_AU_QLD";
      TC_AU_QLD = new State(_TC_AU_QLD);
      _TC_DE_RP = "TC_DE_RP";
      TC_DE_RP = new State(_TC_DE_RP);
      _TC_RI = "TC_RI";
      TC_RI = new State(_TC_RI);
      _TC_DE_SL = "TC_DE_SL";
      TC_DE_SL = new State(_TC_DE_SL);
      _TC_SK = "TC_SK";
      TC_SK = new State(_TC_SK);
      _TC_DE_SN = "TC_DE_SN";
      TC_DE_SN = new State(_TC_DE_SN);
      _TC_DE_ST = "TC_DE_ST";
      TC_DE_ST = new State(_TC_DE_ST);
      _TC_DE_SH = "TC_DE_SH";
      TC_DE_SH = new State(_TC_DE_SH);
      _TC_AU_SA = "TC_AU_SA";
      TC_AU_SA = new State(_TC_AU_SA);
      _TC_SC = "TC_SC";
      TC_SC = new State(_TC_SC);
      _TC_SD = "TC_SD";
      TC_SD = new State(_TC_SD);
      _TC_AU_TAS = "TC_AU_TAS";
      TC_AU_TAS = new State(_TC_AU_TAS);
      _TC_TN = "TC_TN";
      TC_TN = new State(_TC_TN);
      _TC_TX = "TC_TX";
      TC_TX = new State(_TC_TX);
      _TC_DE_TH = "TC_DE_TH";
      TC_DE_TH = new State(_TC_DE_TH);
      _TC_UT = "TC_UT";
      TC_UT = new State(_TC_UT);
      _TC_VT = "TC_VT";
      TC_VT = new State(_TC_VT);
      _TC_AU_VIC = "TC_AU_VIC";
      TC_AU_VIC = new State(_TC_AU_VIC);
      _TC_VA = "TC_VA";
      TC_VA = new State(_TC_VA);
      _TC_WA = "TC_WA";
      TC_WA = new State(_TC_WA);
      _TC_WV = "TC_WV";
      TC_WV = new State(_TC_WV);
      _TC_AU_WA = "TC_AU_WA";
      TC_AU_WA = new State(_TC_AU_WA);
      _TC_WI = "TC_WI";
      TC_WI = new State(_TC_WI);
      _TC_WY = "TC_WY";
      TC_WY = new State(_TC_WY);
      _TC_YT = "TC_YT";
      TC_YT = new State(_TC_YT);
    }

    static {
      initValues0();
    }
/**
Returns the String representation of the enumeration, equivalent to toString()
 */
    public java.lang.String getValue() { return _value_;}
/**
Returns the enumeration instance which matches the String.<p><b>Note:</b> Requires a preceding "TC_" to be appended to the code value of a typekey
 */
    public static State fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        State enumeration = (State) internalFromCode(value);
        if (enumeration == null) enumeration = (State) internalFromCode("TC_" + value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public java.lang.String toCode() {
        if (_value_.length() <= 3 || _value_ == null){
            return _value_;
        }
        if (_value_.startsWith("TC_")){
            return _value_.substring(3);
        }
        return toString();
    }
    public static State fromCode(java.lang.String value) {
        try {
            return fromString("TC_" + value);
        } catch (java.lang.IllegalArgumentException iae) {
           return null;
        }
    }
    private static State internalFromCode(java.lang.String value){
        State enumeration = (State)
            _table_.get(value);
        return enumeration;
    }
    public static State fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(State.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://enumeration.webservices.ab.guidewire.com/", "State"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}
