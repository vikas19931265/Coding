/**
 * ITypelistToolsAPIService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2.1 Feb 24, 2009 (02:51:19 PST) WSDL2Java emitter.
 */

package com.guidewire.ab.webservices.api;

public interface ITypelistToolsAPIService extends javax.xml.rpc.Service {

/**
 * ITypelistToolsAPI provides methods that allow for the extraction
 * of typelist data from the
 * system.
 */
    public java.lang.String getITypelistToolsAPIAddress();

    public com.guidewire.ab.webservices.api.ITypelistToolsAPI getITypelistToolsAPI() throws javax.xml.rpc.ServiceException;

    public com.guidewire.ab.webservices.api.ITypelistToolsAPI getITypelistToolsAPI(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
