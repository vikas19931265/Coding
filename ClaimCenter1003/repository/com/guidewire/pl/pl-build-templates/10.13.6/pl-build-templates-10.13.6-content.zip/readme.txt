The release notes and documentation for this release are available for download on the Guidewire Community at the same location as the product release software.

Please visit the Guidewire Community.
