/*

    It is not possible to use the super/ this  keyword inside the static area.

*/
package thisVssuperMixed;


class Testing
{
    int i=100;
}





class Test0 extends Testing {
    

 
 public static void main(String[] args)
 {
     
  /*
     System.out.println(super.i);
     
     error: non-static variable super cannot be referenced from a static context
     System.out.println(super.i);
1 error
     
 
     this is illegal as we can cannot use super and this keywords inside the static context.
     
     */
 
 
 }
 
 
 }
//--------------------------------------------------------------------------*********--------------------------------------------------------------------------