/*


super()/this()
======================

1) We can use only in constructor.

2) We can use only in first line after constructor.

3) We cannot use both of them simultaneously.






super()/this()                                              super, this
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

1. These are constructors to call super                     these are keywords to refers super class
   class and current class constructors                     and current class instance members.


2. We can use only in constructors at first line.           We can use anywhere except static area.( important).                          

3. We can use super() and this() only once inside.          We can use this any number of times.




*/

//--------------------------------------------------------------------------*********--------------------------------------------------------------------------