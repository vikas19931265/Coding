/*

case 1:
==========================

We can use throws keyword for methods and constructors but not for classes

*/
package eThrowsKeyword;


 class Test41  throws Exception {  // class cannot throw exception
    

     Test41()  throws Exception // allowed
     {
         
         
     }
 
 
 
       void m1() throws Exception  // allowed.

     {
         
      
     }
 
 
 }


//-------------------------------------------------------------------------REVISED-----------------------------