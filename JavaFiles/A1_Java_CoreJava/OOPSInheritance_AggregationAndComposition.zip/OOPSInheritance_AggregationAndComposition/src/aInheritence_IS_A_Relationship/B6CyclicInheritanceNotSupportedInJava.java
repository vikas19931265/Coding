/*

Cyclic inheritance
====================

Cyclic inheritance is not allowed in java.

Example1
=========

class A extends B{}

class B extends A{} // CE : Cyclic  inheritance involving A


Example2
===========

class A extends A{} // CE: cyclic inheritance involving A.


*/
