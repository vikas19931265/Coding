/*

Types of inheritance in java
=================================

On the basis of class, there can be three types of inheritance in java: 

single 
multilevel and
hierarchical.

In java programming, multiple and hybrid inheritance is supported through interface only. 


*/