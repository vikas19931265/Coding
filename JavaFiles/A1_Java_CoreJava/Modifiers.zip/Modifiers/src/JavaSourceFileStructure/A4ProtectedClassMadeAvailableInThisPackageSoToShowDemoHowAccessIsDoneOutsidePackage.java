/* protected method made available here to show demo on how access is done from outside package through inheritance.

1. We have written a code here and we will be trying to access it from outside the package that is in the package Member methods.
   named with file protectedmethod through inheritance.


 */
package JavaSourceFileStructure;


public class A4ProtectedClassMadeAvailableInThisPackageSoToShowDemoHowAccessIsDoneOutsidePackage
{
    protected void m1()
    {
        System.out.println("The most misunderstood modifier");
    }
}

//------------------------------------------------------------------------------------------********************--------------------------------------