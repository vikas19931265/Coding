/*
Class
==============

Collection of objects is called class. It is a logical entity.

A class can also be defined as a blueprint from which you can create an individual object.
Class doesn't consume any space.


*/


// Syntax of Class


class ClassSample
{
    // type instance variable    
    
    /*
        type methodOne(argumentList)
        
        {
    
    
        }
    
    */
    
}