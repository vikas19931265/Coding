package aWhatIsPolymporphism;

/*

There are 3 most importanat OOPS features.

        1) Encapsulation talks about Security.

        2) Polymorphism talks about Flexibility

        3) Inheritance talks about reusability.



*/

//--------------------------------------------------------------------------*********-------------------------------------------------------------