//METHOD SIGNATURE


package aWhatIsPolymporphism;


 class methodSignature {
    

    public static void main(String args[])
            
    {
        /*
        
        1. In java method signature consists of method names followed by 
           argument types.
        2. modifier is not a signature.
        3. Void which is return type is also not a  part of a method signature.
        4. Here only main(String args[]) is the method signature.
        
        5. In a class 2 methods with the same signatures are not allowed.
        
        example
        
            class test
        {
            public void m1( int i) //Signature......m1(int)
        {
           
        }
        
         WITHIN A CLASS 2 METHODS WITH THE SAME SIGNATURE ARE NOT ALLOWED.
            
        public int m1(int x)   //Signature.....m1(int)....same signature in a same class is not allowed in java.
        {
              return 10;
        
        {
        
        */
        
    
         }



}

//-----------------------------------------------------------------------------*********-------------------------------------------------------------