/*

class loader subsystem figure:




                     Verify 
                        |
                     prepare 
                        |
                     resolve                   
                        
Loading      --->    Linking ------->      Initialization



This is diagram of class loading process.



While loading, linking and initialization if any error occurs then we will get the run
time exception saying Java.lang.Linkage error.


*/
