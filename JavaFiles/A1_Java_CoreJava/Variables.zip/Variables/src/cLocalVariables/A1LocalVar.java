package cLocalVariables;

/*  // Local Variables.


1. Sometimes to meet temporary requirements of the programmer we can declare variables
   inside a method or block or constructor.

2. Such type of variables are called local variables or temporary variables or stack
   variables or automatic variables.

3. Local variables will be stored inside stack memory.

4. Local variables will be created while executing the block in which we declared it.

5. Once block executing completes automatically local variable will be destroyed.

6. Hence the scope of local variable is the block in which we declared it.


    eg.

            m1(){
                    int x=10; // local var.
                }   


            static
                {
                    int x=10;

                }

             for( int i=0;i<=5;i++)
                {
                    int x=10;
                }


                    


*/
