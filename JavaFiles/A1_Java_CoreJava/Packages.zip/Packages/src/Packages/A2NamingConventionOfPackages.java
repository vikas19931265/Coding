/* Naming convention for the packages.
==========================================================================

There is one universally accepted naming convention for the packages. That is to use internet domain name
in reverse order.


    eg 
            com. icicibank.loan.housing.Account

com.icicibank( client's internet domain name in reverse)

loan ( module name)

housing( submodule name)

Account( class name)



*/
//-------------------------------------------------------------------------------------------******************---------------------------------------------