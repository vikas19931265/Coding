

/*

Web Application vs Enterprise Application
===============================================================================

A Web application can be developed by only web related technologies like Servlets,
JSPs , HTML, CSS files , Javascript etc. Example Online Library Management System
Online Shopping Cart.

An enterprise application can be developed by any technology from J2EE like Servlets,
JSPs, EJBs, JMS Components etc. Example Banking application, Telecom based project etc.

note
=========

J2EE or JEE compatible application is Enterprise application.

*/

