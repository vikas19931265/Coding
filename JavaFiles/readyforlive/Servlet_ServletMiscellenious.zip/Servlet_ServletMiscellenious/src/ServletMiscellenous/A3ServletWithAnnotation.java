/*

Servlet with Annotation (feature of servlet3):
===============================================================================

Annotation represents the metadata. If you use annotation, deployment descriptor (web.xml file) is not required. 

But you should have tomcat7 as it will not run in the previous versions of tomcat. 



@WebServlet annotation is used to map the servlet with the specified name.




*/