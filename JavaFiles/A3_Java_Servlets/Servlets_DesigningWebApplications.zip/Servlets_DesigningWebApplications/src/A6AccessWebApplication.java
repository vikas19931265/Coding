/*

STEP 5: ACCESS THE WEB APPLICATION:
========================================================

There are 2 ways to access the web applications.

1. Open web browser and type the complete URL on address bar.   
    http://localhost:8080/app1/servlet

2. Open web browser type the URL up to
    http://localhost:8080

If we do the above automatically the Tomcat Home Page will be opened, where we have to select
Manager Applications, provide username and password in Security window and click on OK button.
If we do the above automatically list of applications will be opened, where we have to select the
required application.




*/