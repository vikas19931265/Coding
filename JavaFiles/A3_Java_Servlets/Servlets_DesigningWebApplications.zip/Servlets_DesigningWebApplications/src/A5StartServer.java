/*


STEP 4: START THE SERVER:
============================================


There are 3 ways to start the server.

1. Execute either startup.bat file or Tomcat7 Service Runner available under bin folder of Tomcat
   server.

    C:\Tomcat 7.0\bin

2. Use system program monitor Tomcat
    Start
        All Programs
            Apache Tomcat 7.0

3. Use Apache Tomcat System Service
    
        Type services.MSC in search field
             Select Start Service Icon.




*/