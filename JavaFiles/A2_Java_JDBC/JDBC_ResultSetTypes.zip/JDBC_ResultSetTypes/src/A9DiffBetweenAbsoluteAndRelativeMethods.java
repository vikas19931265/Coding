/*

Q. What is the difference Between absolute() and relative()methods?
======================================================================

absolute() method will always work either from BFR or from ALR.
relative() method will work wrt to current position.

In both methods +ve number means we have to move forward direction and -ve number means
we have to move backward direction.

Note:
1. rs.last() and rs.absolute(-1) both are equal
2. rs.first() and rs.absolute(1) both are equal



*/