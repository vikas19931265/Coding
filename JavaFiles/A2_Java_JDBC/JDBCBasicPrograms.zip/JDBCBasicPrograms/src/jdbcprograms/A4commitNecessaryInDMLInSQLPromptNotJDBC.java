
/*

Note:
================

From SQL Plus Command Prompt, if we are performing any Database Operations(DML) then compulsory
we should perform Commit Operation explicitly because Auto Commit Mode is not enabled.

From JDBC Application if we perform any Database Operations then the Results will be committed
automatically and we are not required to Commit explicitly, because in JDBC Auto Commit is
enabled by default.


*/


