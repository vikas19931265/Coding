/*

Differences between java.util.Date and java.sql.Date
========================================================



java.util.Date                                                                 java.sql.Date


1.It is general Utility Class to handle Dates in                        1.It is specially designed class to handle
our Java Program.                                                        dates w.r.t to DB operations

2. It represents both date and time                                     2. It represents only date but not time.



Note: In sql package Time class is available to represent Time values and TimeStamp class is
available to represent both Date and Time.



*/