

package JDBCIntroduction;


import java.sql.DriverManager;

import java.sql.*;

 class JDBCConnectionDemo {
    
public static void main(String[] args) throws Exception
{
    
    Class.forName("oracle.jdbc.OracleDriver"); // This will load the Driver class. Inside the driver class there is 
                                               // already static block code written for the purpose of registration of the
                                               // driver. So first forName() method of Class is called and then operation is performed
                                               // on the respective class which is loaded.
    
     Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","hr") ; 
     /*
     
     1. In this step we are tring to create the Connection object.
     2. Here Connection is an interface which will be holding the object of one of its implementation class.
     
     */
     
     
       
        Statement stmt=con.createStatement(); // In this step we are creating the Statement object.
        
        ResultSet rs= stmt.executeQuery("select * from employees"); // Executing the query on the statement.
        
        
        while(rs.next()) // This will loop for the entire table.
        {
            System.out.println(rs.getInt(1)+" " + rs.getString(2)+ " \t "+ rs.getString(3)+"\t\t " ); // Here 1 , 2 ,3 specifies the column numbers.
            
            
        }
    
    
}  



}

/*
run:
100 Steven 	 King		 
101 Neena 	 Kochhar		 
102 Lex 	 De Haan		 
103 Alexander 	 Hunold		 
104 Bruce 	 Ernst		 
105 David 	 Austin		 
106 Valli 	 Pataballa		 
107 Diana 	 Lorentz		 
108 Nancy 	 Greenberg		 
109 Daniel 	 Faviet		 
110 John 	 Chen		 
111 Ismael 	 Sciarra		 
112 Jose Manuel 	 Urman		 
113 Luis 	 Popp		 
114 Den 	 Raphaely		 
115 Alexander 	 Khoo		 
116 Shelli 	 Baida		 
117 Sigal 	 Tobias		 
118 Guy 	 Himuro		 
119 Karen 	 Colmenares		 
120 Matthew 	 Weiss		 
121 Adam 	 Fripp		 
122 Payam 	 Kaufling		 
123 Shanta 	 Vollman		 
124 Kevin 	 Mourgos		 
125 Julia 	 Nayer		 
126 Irene 	 Mikkilineni		 
127 James 	 Landry		 
128 Steven 	 Markle		 
129 Laura 	 Bissot		 
130 Mozhe 	 Atkinson		 
131 James 	 Marlow		 
132 TJ 	 Olson		 
133 Jason 	 Mallin		 
134 Michael 	 Rogers		 
135 Ki 	 Gee		 
136 Hazel 	 Philtanker		 
137 Renske 	 Ladwig		 
138 Stephen 	 Stiles		 
139 John 	 Seo		 
140 Joshua 	 Patel		 
141 Trenna 	 Rajs		 
142 Curtis 	 Davies		 
143 Randall 	 Matos		 
144 Peter 	 Vargas		 
145 John 	 Russell		 
146 Karen 	 Partners		 
147 Alberto 	 Errazuriz		 
148 Gerald 	 Cambrault		 
149 Eleni 	 Zlotkey		 
150 Peter 	 Tucker		 
151 David 	 Bernstein		 
152 Peter 	 Hall		 
153 Christopher 	 Olsen		 
154 Nanette 	 Cambrault		 
155 Oliver 	 Tuvault		 
156 Janette 	 King		 
157 Patrick 	 Sully		 
158 Allan 	 McEwen		 
159 Lindsey 	 Smith		 
160 Louise 	 Doran		 
161 Sarath 	 Sewall		 
162 Clara 	 Vishney		 
163 Danielle 	 Greene		 
164 Mattea 	 Marvins		 
165 David 	 Lee		 
166 Sundar 	 Ande		 
167 Amit 	 Banda		 
168 Lisa 	 Ozer		 
169 Harrison 	 Bloom		 
170 Tayler 	 Fox		 
171 William 	 Smith		 
172 Elizabeth 	 Bates		 
173 Sundita 	 Kumar		 
174 Ellen 	 Abel		 
175 Alyssa 	 Hutton		 
176 Jonathon 	 Taylor		 
177 Jack 	 Livingston		 
178 Kimberely 	 Grant		 
179 Charles 	 Johnson		 
180 Winston 	 Taylor		 
181 Jean 	 Fleaur		 
182 Martha 	 Sullivan		 
183 Girard 	 Geoni		 
184 Nandita 	 Sarchand		 
185 Alexis 	 Bull		 
186 Julia 	 Dellinger		 
187 Anthony 	 Cabrio		 
188 Kelly 	 Chung		 
189 Jennifer 	 Dilly		 
190 Timothy 	 Gates		 
191 Randall 	 Perkins		 
192 Sarah 	 Bell		 
193 Britney 	 Everett		 
194 Samuel 	 McCain		 
195 Vance 	 Jones		 
196 Alana 	 Walsh		 
197 Kevin 	 Feeney		 
198 Donald 	 OConnell		 
199 Douglas 	 Grant		 
200 Jennifer 	 Whalen		 
201 Michael 	 Hartstein		 
202 Pat 	 Fay		 
203 Susan 	 Mavris		 
204 Hermann 	 Baer		 
205 Shelley 	 Higgins		 
206 William 	 Gietz		 
BUILD SUCCESSFUL (total time: 0 seconds)

*/
