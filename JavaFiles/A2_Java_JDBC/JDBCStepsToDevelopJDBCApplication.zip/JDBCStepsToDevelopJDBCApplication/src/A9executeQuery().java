/*

executeQuery() Method:
==============================================

We can use this Method for Select Operations.

Because of this Method Execution, we will get a Group of Records, which are represented by
ResultSet Object.

Hence the Return Type of this Method is ResultSet.

public ResultSet executeQuery(String sqlQuery) throws SQLException
Eg: ResultSet rs = st.executeQuery("select * from movies");


*/