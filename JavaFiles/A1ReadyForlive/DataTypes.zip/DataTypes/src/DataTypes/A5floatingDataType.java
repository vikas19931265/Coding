// FLOATING DATA TYPES.                                                                                                                                 




package DataTypes;

 class floatingDataType {
    
/*
     Floating data types( float / boolean) are used to represent digits with decimals.


    float data types

1. If we want to represent a digit with less precision like 5,6 decimal places then go for float data type.
2. Single Precision (less accuracy meaning less number of digits after decimal places is supported]
3. SIZE- 4 BYTE ( 32 BITS).
4. RANGE-> -3.4e10pow38 to 3.4e10pow38
5. DEFAULT VALUE-> 0.0

*/



}