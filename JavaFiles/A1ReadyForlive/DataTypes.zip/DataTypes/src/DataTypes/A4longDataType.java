// long Data Type                                                                        


package DataTypes;


 class longDataType {
    
/*
1. Sometimes int may not be enough to hold big values then we should go for long type.
2. Example the amount of distance travelled by light in 1000 days , to hold this value int may not be enough
   then we should go for long data type example long l=1,26000*60*24*24*1000;
3. Example 2-> The number of characters present in a big file may exceed int range hence the return type of length type method
   is long not int in filehandling operations.
                    long l= f.length();


SIZE: 8 bytes( 64 bits)
RANGE: - 2 pow 63 to ((2 pow 63)-1)
DEFAULT VALUE-> 0
    
*/



}
