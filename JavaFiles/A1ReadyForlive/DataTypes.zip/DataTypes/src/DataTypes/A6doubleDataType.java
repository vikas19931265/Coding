//                                                                         DOUBLE DATA TYPE                                                            

package DataTypes;


 class doubleDataType {
    
public static void main(String[] args)
{
    
    
    /*
    
     double data type

1. By default every decimal number is of double data type only.
2. double Precision( more accurate)
3. SIZE-> 8 bytes( 32 bits)
4. RANGE-> -1.7e308 to 1.7e308
5. DEFAULT VALUE-> 0.0    
    
    */
    
}


}
